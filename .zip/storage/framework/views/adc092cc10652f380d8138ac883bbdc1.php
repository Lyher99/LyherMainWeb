<nav class="navbar navbar-expand-lg fixed-top">
  <div class="container">
      <!-- Logo on the Left -->
      <a class="navbar-brand fw-bold" href="/">
          
          CHAMPA NETWORK
      </a>

      <!-- Toggler for Mobile -->
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Links on the Right -->
      <div class="collapse navbar-collapse justify-content-end" id="navbarContent">
          <ul class="navbar-nav mb-2 mb-lg-0">
              <li class="nav-item">
                  <a class="nav-link active fw-bold" href="#">Home</a>
              </li>
              <li class="nav-item">
                  <a class="nav-link fw-bold" href="/">About us</a>
              </li>
              <li class="nav-item">
                  <a class="nav-link fw-bold" href="#footer">Contact Us</a>
              </li>
             
          </ul>
      </div>
  </div>
</nav>
<?php /**PATH D:\OneDrive\File\Code\web\Hosting\LyherV3\LyherMainWeb\LyherMainWeb\resources\views/layout/nav.blade.php ENDPATH**/ ?>